import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("1. Try only with Stick");
            System.out.println("2. Try adapt Stick to Spearhead, then make Spear");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("\nPrimitive man tries to pierce own prey with stick. It doesn't work.");
                    break;
                case 2:
                    demonstrateAdapterPattern();
                    break;
                default:
                    System.out.println("Invalid choice. Please choose again.");
            }
        } while (choice != 2);

        scanner.close();
    }

    private static void demonstrateAdapterPattern() {
        // Creating a stone spearhead (adaptee interface)
        StoneSpearhead stoneSpearhead = new StoneSpearhead();

        // Creating a wooden stick (the interface we are referring to) using the adapter
        WoodenStick woodenStick = new RopeAdapter(stoneSpearhead);
        woodenStick.hitPrey();
    }
}
