//Adapter as rope, which implements(inputs) the Stick interface
public class RopeAdapter implements WoodenStick {

    //creating reference to the StoneSpearhead and adapting it's method
    private StoneSpearhead stoneSpearhead;
    public RopeAdapter(StoneSpearhead stoneSpearhead) {
        this.stoneSpearhead = stoneSpearhead;
    }
    @Override
    public void hitPrey(){
        System.out.println("Primitive man ties the stick and the spearhead tightly, and gets a spear!");
        this.stoneSpearhead.piercePrey();
    }
}