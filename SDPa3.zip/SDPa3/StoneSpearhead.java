//Spearhead (2nd interface)
public class StoneSpearhead {
    //method that can be called only in StoneSpearhead
    public void piercePrey() {
        System.out.println("Primitive man pierces his prey with a spear.");
    }
}