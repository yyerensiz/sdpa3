//Interface of stick
public interface WoodenStick {
    void hitPrey();
}